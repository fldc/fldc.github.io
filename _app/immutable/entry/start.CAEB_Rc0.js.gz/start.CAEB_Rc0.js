import{l as o,a as r}from"../chunks/BmbdR-cI.js";export{o as load_css,r as start};
