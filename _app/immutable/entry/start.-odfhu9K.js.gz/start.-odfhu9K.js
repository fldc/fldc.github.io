import{l as o,a as r}from"../chunks/DBj8_EDm.js";export{o as load_css,r as start};
